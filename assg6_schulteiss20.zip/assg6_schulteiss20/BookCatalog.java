/*
 * @author Sariah Schulteis 
 * This class is for Book Catalog and it is stored in an array list object
 */
package assg6_schulteiss20;

import java.io.*;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class BookCatalog implements BookCatalogInterface {

	Scanner inputStream = null;
	ArrayList<Book> list = new ArrayList<Book>();

	/*
	 * Default constructor
	 */
	public BookCatalog() {
		list = new ArrayList<Book>();
	}

	/*
	 * This method displays all the books in the catalog.
	 */
	public void displayCatalog() {
		for (Book i : list) {
			System.out.println(i);

		}

	}

	/*
	 * The method loads the data containing all the books from a given file.
	 * 
	 * @param filename
	 */
	public void loadData(String filename) {
		
		try {
			inputStream = new Scanner(new File(filename));
		}
		catch (FileNotFoundException e) {
			System.out.println("Error opening the file");
			System.exit(0);
		}
		Book book = null; 
		while(inputStream.hasNextLine()) {
			book = new Book(inputStream.nextLine(), inputStream.nextLine(), inputStream.nextLine(), inputStream.nextLine(), inputStream.nextLine());
			inputStream.nextLine();
			list.add(book);
		}
		}
	
		
		
	
   



			
	

	/*
	 * This method returns a book object if found
	 * 
	 * @param title
	 * 
	 * @return i.toString
	 * 
	 * @return null if i.getTitle does not equal title
	 */
	public String searchForBook(String title) {
String str = "";
		for (Book i : list) {
			if (i.getTitle().equals(title)) {
				return (i.toString());
			}
			else {
				str = "No book with that name";
			}
	}
		return str;
	}
		    
		

	/*
	 * This method adds a new book to the file
	 * 
	 * @param ISBN
	 * 
	 * @param title
	 * 
	 * @param author
	 * 
	 * @param publisher
	 * 
	 * @param year
	 * 
	 * @return false if book is already included
	 * 
	 * @return true if book needs to be added
	 */
	public boolean addBook(String ISBN, String title, String author, String publisher, String year) {
		for (Book i : list) {
			if (i.getTitle().compareTo(title) == 0) {
				System.out.println("The book is already there");
				return false;
			} else {
				list.add(new Book(ISBN, title, author, publisher, year));
				return true;
			}
		}
		return false;
	}

	/*
	 * This method is used to update the information of an existing book
	 * 
	 * @param ISBN
	 * 
	 * @param title
	 * 
	 * @param author
	 * 
	 * @param publisher
	 * 
	 * @param year
	 * 
	 * @return true if getTitle equals title
	 * 
	 * @return false if getTitle does not equal title
	 */
	public boolean updateBook(String ISBN, String title, String author, String publisher, String year) {
		for (Book i : list) {
			if (i.getTitle().equals(title)) {
				i.setISBN(ISBN);
				i.setAuthor(author);
				i.setPublisher(publisher);
				i.setYear(year);
				return true;}
			 else {
				System.out.println("This book does exist");
			return false;
			}

				
	}
		return false;
	}
	



	/*
	 * This method removes the book from the catalog if the title is found
	 * 
	 * @param title
	 * 
	 * @return true if title equals book.getTitle
	 * 
	 * @return false if title does not equal book.getTitle
	 */
	public boolean removeBook(String title) {
		for (int i = 0; i < list.size(); i++) {
			Book book = list.get(i);
			if (title.equalsIgnoreCase(book.getTitle())) {
				list.remove(i);
				return true;
			}
		}
		System.out.println("Cannot remove book from catalog");
		return false;
		
	}

	/*
	 * This method returns the ArrayList object with all the books by the given
	 * publisher
	 * 
	 * @param publisher
	 * 
	 * @return books.toString (the arrayList object)
	 */
	public String getBookByPublisher(String publisher) {
		
		ArrayList<Book> books = new ArrayList<Book>();
		
		for (int i = 0; i < list.size(); i++) {
			Book book = list.get(i);
			if (publisher.equalsIgnoreCase(book.getPublisher())) {
				System.out.println(book.getTitle());
			}
			
	
		//return books.toString();
	}
		return books.toString();
		
	}	
		
			



	/*
	 * This method sorts all the books based on title
	 */
	public void sortByTitle() {
		Collections.sort(list);

	}

	/*
	 * This method writes the book catalog back to the file is the data has been
	 * changed
	 */
	@Override
	public void save() {
		try {
			String filename = "assg6_catalog.txt";
			FileWriter myWriter = new FileWriter(filename);
			for (Book i : list) {
				myWriter.write(i.getISBN() + "\n");
				myWriter.write(i.getTitle() + "\n");
				myWriter.write(i.getAuthor() + "\n");
				myWriter.write(i.getPublisher() + "\n");
				myWriter.write(i.getYear() + "\n");
				myWriter.write("\n");
			}
			myWriter.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
		/*String fileName = "assg6_catalog.txt";
		PrintWriter outputStream = null;
		try {
			outputStream = new PrintWriter(fileName);
		}
		catch(IOException e) {
			System.out.println("Error opening file");
			System.exit(0);
		}
		for(int i = 0; i < list.size(); i++) {
			outputStream.println(list.get(i));
		}
		outputStream.close();
		*/
	}
}
