/*
 * @author Sariah Schulteis 
 * This class is the Interface file for the Book Catalog
 */
package assg6_schulteiss20;

public interface BookCatalogInterface {
/*
 *  The method loads the data containing all the books from a given file. 
 */
	public void loadData(String file);
/*
 *  This method displays all the books in the catalog. 
 */
	public void displayCatalog();
/*
 * This method returns a book object if found 
 */
	public String searchForBook(String title);
/*
 * This method adds a new book to the file
 */
	public boolean addBook(String ISBN, String title, String author, String publisher, String year);
/*
 *  This method is used to update the information of an existing book
 */
	public boolean updateBook(String ISBN, String title, String author, String publisher, String year);
/*
 * This method removes the book from the catalog if the title is found
 */
	public boolean removeBook(String title);
/*
 * This method returns the ArrayList object with all the books by the given publisher
 */
	public String getBookByPublisher(String publisher);
/*
 * This method writes the book catalog back to the file is the data has been changed
 */
	public void save();
/*
 * This method sorts all the books based on title
 */
	public void sortByTitle();

}
