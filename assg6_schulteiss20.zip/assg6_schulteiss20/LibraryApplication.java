/*
 * @author Sariah Schulteis
 * This class is for the main program, it reads the data from input file, displays menu options, and performs various tasks that user selects
 */
package assg6_schulteiss20;

import java.util.Scanner;

public class LibraryApplication {
	public static void main(String[] args) {

		BookCatalog list = new BookCatalog();
		list.loadData("assg6_catalog.txt");

		do {
			System.out.println("1. Display all the books in the catalog \r\n" + "2. Search for a book  \r\n"
					+ "3. Add a new book \r\n" + "4. Update an existing book \r\n" + "5. Remove a book \r\n"
					+ "6. Display books by a publisher \r\n" + "7. Sort all the books based on title \r\n"
					+ "8. Save data \r\n" + "9. Exit ");

			Scanner keyboard = new Scanner(System.in);
			String input = keyboard.nextLine();

			switch (input) {
			// display 
			case "1":
				list.displayCatalog();
				break;
			// search for book 
			case "2":
				System.out.println("Enter a title: ");
				String title = keyboard.nextLine();
				System.out.println(list.searchForBook(title));
				break;
			// add a new book 
			case "3":
				System.out.println("Enter an ISBN, title, author, publisher, and year");
				Scanner keyboard2 = new Scanner(System.in);
				String ISBN2 = keyboard2.nextLine();
				String title3 = keyboard2.nextLine();
				String author2 = keyboard2.nextLine();
				String publisher2 = keyboard2.nextLine();
				String year2 = keyboard2.nextLine();
				list.addBook(ISBN2, title3, author2, publisher2, year2);
				break;
			// update an existing book 
			case "4":
				System.out.println("Enter a book title");
				String title1 = keyboard.nextLine();
				Scanner keyboard1 = new Scanner(System.in);
				System.out.println("Enter an ISBN or press enter to skip");
				String ISBN1 = keyboard1.nextLine();
				System.out.println("Enter an author or press enter to skip");
				String author = keyboard1.nextLine();
				System.out.println("Enter a publisher or press enter to skip");
				String publisher = keyboard1.nextLine();
				System.out.println("Enter a year or press enter to skip");
				String year = keyboard1.nextLine();
				list.updateBook(ISBN1, title1, author, publisher, year);
				break;
				

			// remove a book 
			case "5":
				System.out.println("Enter the title of a book");
				String title2 = keyboard.nextLine();
				list.removeBook(title2);
				break;
			// display book by publisher 
			case "6":
				System.out.println("Enter a publisher");
				String publisher3 = keyboard.nextLine();
				list.getBookByPublisher(publisher3);

				// sort 
			case "7":
				list.sortByTitle();
				// save 
			case "8":
				list.save();
				// exit 
			case "9":
				list.save();
				System.exit(0);
			}
			System.out.println("Press enter to continue");
			Scanner keyboard2 = new Scanner(System.in);
			String enter = keyboard2.nextLine();
			if (!enter.equalsIgnoreCase(enter)) {
				System.out.println();
			}
		}

		while (true);

	}
}
