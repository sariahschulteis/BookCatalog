/*
 * @author Sariah Schulteis
 * Contains all the information and methods for one book
 */
package assg6_schulteiss20;

/*
 * Initializes variables
 */
public class Book implements Comparable <Book>{

	private String ISBN, title, author, publisher, year;
/*
 * Constructor with given ISBN, title, author, publisher, and year
 * @param ISBN
 * @param title
 * @param author
 * @param publisher
 * @param year
 */
	public Book(String ISBN, String title, String author, String publisher, String year) {
		this.ISBN = ISBN;
		this.title = title;
		this.author = author;
		this.publisher = publisher;
		this.year = year;
	}
	/*
	 * Retrieves ISBN
	 * @return ISBN
	 */
		public String getISBN() {
			return this.ISBN;
		}
	/*
	 * Retrieves title
	 * @return title
	 */
		public String getTitle() {
			return this.title;
		}
	/*
	 * Retrieves author
	 * @return author
	 */
		public String getAuthor() {
			return this.author;
		}
	/*
	 * Retrieves publisher
	 * @return publisher
	 */
		public String getPublisher() {
			return this.publisher;
		}
	/*
	 * Retrieves year
	 * @return year
	 */
		public String getYear() {
			return this.year;
		}
/*
 * Modifies ISBN
 * @param ISBN
 */
	public void setISBN(String ISBN) {
		this.ISBN = ISBN;
	}
/*
 * Modifies author
 * @param author
 */
	public void setAuthor(String author) {
		this.author = author;
	}
/*
 * Modifies publisher
 * @param publisher
 */
	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}
/*
 * Modifies year
 * @param year
 */
	public void setYear(String year) {
		this.year = year;
	}

/*
 * Returns the string with ISBN, title, author, publisher, and year
 * @return ISBN
 * @return title
 * @return author
 * @return publisher
 * @return year
 */
	public String toString() {
		return "ISBN: " + ISBN + "\n" + "Title: " + title + "\n" + "Author: " + author + "\n" + "Publisher: "
				+ publisher + "\n" + "Year: " + year + "\n";
	}
/*
 * Checks if title is equal to object's title and returns true or false
 * @return true
 * @return false
 */
	public boolean equals(Book obj) {
		if (this.getTitle().equals(obj.getTitle()))
			return true;
		else {
			return false;
		}
	}
/*
 * Compares title to Book object title
 * @return title
 */
	public int compareTo(Book b) {
		return this.title.compareToIgnoreCase(b.title);
	}
}